package com.brunojiavaliacaocontinuada1.ac1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ac1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
